<h3>Other pages</h3>
<ul class="f">
	<li><a href="/about-this-site/">About this site</a></li>
	<li><a href="/about-me/">About me</a></li>
	<li><a href="/dogma/">WordPress theme: Dogma</a></li>
</ul>

<?php wp_footer(); ?>

</body>
</html>
