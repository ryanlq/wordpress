<?php get_header(); ?>

<h1>Page not found</h1>
<p>Read <a href="/">the most recent post</a>, or select one of the articles from the list below.</p>

<?php include 'allposts.php'; ?>

<?php get_footer(); ?>